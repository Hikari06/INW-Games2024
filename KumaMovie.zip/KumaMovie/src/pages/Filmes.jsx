function Filmes() {
    return ( 
        <h1>Filmes</h1>
     );
}

export default Filmes ;